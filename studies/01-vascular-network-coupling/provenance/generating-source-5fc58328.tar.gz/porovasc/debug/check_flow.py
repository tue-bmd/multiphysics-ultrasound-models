"""Flow invariants and physiological checks.

Physiology anchors:
  prostate perfusion            15-20 mL/min/100 g   (~4-5 mL/min for 22 mL)
  velocity, 400-600 um arteries 20-80 mm/s
  velocity, 30-60 um arterioles  2-15 mm/s
  arteriolar-end pressure       30-40 mmHg   (imposed by calibration)
  venular-end pressure          10-20 mmHg   (NOT imposed: a check)
  capillaries per terminal arteriole  ~5-30 (verification of R_bed)
  feeder -> terminal transit    ~1-4 s (CEUS wash-in scale)
"""
from __future__ import annotations
import numpy as np
from ..geometry.network import Network, GLAND_SEMI
from ..physics.flow import Flow, ETA, MMHG, P_ART, P_VEN, P_ART_END


def _hdr(t): print("\n" + t); print("-" * len(t))
def _pf(ok, msg): print(("PASS  " if ok else "FAIL  ") + msg); return ok


def check(net: Network, fl: Flow) -> bool:
    ok = True
    n = net.n; A = net.kind == 0; V = net.kind == 1
    seg_end = np.arange(n)

    _hdr("1. Kirchhoff: net flow into every interior node is zero")
    inflow = np.zeros(n + 2)
    np.add.at(inflow, seg_end, fl.Q)           # flow arrives at the end node
    np.add.at(inflow, fl.start, -fl.Q)         # and leaves the start node
    np.add.at(inflow, fl.bed_a, -fl.Q_bed)
    np.add.at(inflow, fl.bed_v, fl.Q_bed)
    interior = np.ones(n + 2, bool); interior[[fl.inlet, fl.outlet]] = False
    Qref = np.abs(fl.Q).max()
    res = np.abs(inflow[interior]).max() / Qref
    ok &= _pf(res < 1e-9, "max |sum Q| / max|Q| over %d interior nodes = %.1e" % (interior.sum(), res))
    Qin = -inflow[fl.inlet]; Qout = inflow[fl.outlet]
    ok &= _pf(abs(Qin - Qout) / Qin < 1e-9, "inlet flow = outlet flow: %.3f vs %.3f mL/min" % (Qin * 6e7, Qout * 6e7))

    _hdr("2. Pressure monotone along every path")
    dpA = fl.p[fl.start[A]] - fl.p[seg_end[A]]     # should be > 0 (flow p0 -> p1)
    dpV = fl.p[seg_end[V]] - fl.p[fl.start[V]]     # veins: flow p1 -> p0, so end > start
    ok &= _pf(dpA.min() > -1e-9 * P_ART, "arteries: pressure drops along p0->p1 in all %d segments (min dp = %.2e Pa)" % (A.sum(), dpA.min()))
    ok &= _pf(dpV.min() > -1e-9 * P_ART, "veins: pressure drops along p1->p0 in all %d segments (min dp = %.2e Pa)" % (V.sum(), dpV.min()))
    ok &= _pf((fl.Q[A] > 0).all() and (fl.Q[V] < 0).all(), "flow direction: arteries forward, veins backward, everywhere")

    _hdr("3. Total gland flow (OUTPUT of the pressure-driven solve)")
    Vg = 4 / 3 * np.pi * np.prod(GLAND_SEMI) * 1e6            # mL
    mass_g = Vg * 1.05
    perf = Qin * 6e7 / mass_g * 100
    print("      total flow %.2f mL/min for a %.1f mL gland -> %.1f mL/min/100 g   (lit 15-20)" % (Qin * 6e7, Vg, perf))
    ok &= _pf(5 < perf < 60, "perfusion within a factor ~3 of physiology")

    _hdr("4. Velocities by caliber (arteries)")
    d = net.d * 1e6; v = np.abs(fl.v) * 1e3
    for lo, hi, ref in [(400, 700, "20-80"), (150, 400, "8-40"), (60, 150, "3-20"), (30, 60, "2-15")]:
        m = A & (d >= lo) & (d < hi)
        if m.sum():
            print("      %3d-%3d um: n=%5d  v median %5.1f mm/s, 5-95%% [%5.1f, %5.1f]   (lit %s)"
                  % (lo, hi, m.sum(), np.median(v[m]), *np.percentile(v[m], [5, 95]), ref))
    m = A & (d >= 30) & (d < 60)
    ok &= _pf(0.5 < np.median(v[m]) < 40, "arteriolar velocity within an order of magnitude of physiology")

    _hdr("5. Pressures at the bed")
    term = A & net.term
    pa = fl.p[np.where(term)[0]] / MMHG
    pv = fl.p[fl.bed_v] / MMHG
    print("      arterial terminals: mean %.1f mmHg (target %.0f, imposed by calibration), 5-95%% [%.1f, %.1f]"
          % (pa.mean(), P_ART_END / MMHG, *np.percentile(pa, [5, 95])))
    print("      venular ends      : mean %.1f mmHg, 5-95%% [%.1f, %.1f]      (lit 10-20, NOT imposed)"
          % (pv.mean(), *np.percentile(pv, [5, 95])))
    ok &= _pf(8 < pv.mean() < 25, "venular-end pressure in physiological range")
    print("      inlet %.0f mmHg, outlet %.0f mmHg; arterial tree drop %.1f, bed drop %.1f, venous tree drop %.1f mmHg"
          % (P_ART / MMHG, P_VEN / MMHG, P_ART / MMHG - pa.mean(), pa.mean() - pv.mean(), pv.mean() - P_VEN / MMHG))

    _hdr("6. Bed resistance: calibrated value vs capillary geometry (verification of geometry)")
    R_bed_term = 1.0 / (fl.G_bed0)                     # per 30 um-equivalent connection
    d_cap, L_cap = 8e-6, 500e-6
    R_cap = 8 * ETA * L_cap / (np.pi * (d_cap / 2) ** 4)
    N_cap = R_cap / R_bed_term
    print("      R_bed (per %.0f um terminal) = %.2e Pa s/m^3 ; one 8 um x 0.5 mm capillary = %.2e"
          % (net.params.d_term_rve * 1e6, R_bed_term, R_cap))
    print("      -> implied capillaries per terminal arteriole = %.1f   (lit ~5-30)" % N_cap)
    ok &= _pf(2 < N_cap < 100, "implied capillary count per terminal within a factor ~3 of physiology")
    Qb_frac = np.abs(fl.Q_bed).sum() / Qin
    ok &= _pf(abs(Qb_frac - 1) < 1e-9, "all inlet flow passes through the bed (%.6f)" % Qb_frac)

    _hdr("7. Transit times, feeder inlet -> arterial terminals")
    ta = fl.t_arr[np.where(term)[0]]
    print("      median %.2f s, 5-95%% [%.2f, %.2f] s   (CEUS wash-in scale ~1-4 s)" % (np.median(ta), *np.percentile(ta, [5, 95])))
    ok &= _pf(0.2 < np.median(ta) < 15, "transit time within an order of magnitude of the wash-in scale")
    # flow-weighted transit spread: the raw material of dispersion
    w = fl.Q[np.where(term)[0]]
    tm = (w * ta).sum() / w.sum(); ts = np.sqrt((w * (ta - tm) ** 2).sum() / w.sum())
    print("      flow-weighted mean %.2f s, sd %.2f s, relative dispersion RD = %.2f" % (tm, ts, ts / tm))

    _hdr("8. Flow reaching the RVEs")
    from ..geometry.network import in_cube
    mid = 0.5 * (net.p0 + net.p1)
    for q, c in enumerate(net.params.rve_centres):
        c = np.asarray(c); h = net.params.rve_half
        m = in_cube(mid, c, h)
        Qr = np.abs(fl.Q_bed[in_cube(mid[fl.bed_a], c, h)]).sum()
        Vr = (2 * h) ** 3 * 1e6
        print("      RVE %d: bed flow %.3f mL/min in %.2f mL -> %.1f mL/min/100 g (gland mean %.1f)"
              % (q, Qr * 6e7, Vr, Qr * 6e7 / (Vr * 1.05) * 100, perf))

    print("\n" + "=" * 60 + "\nFLOW " + ("OK" if ok else "NOT OK"))
    return ok
